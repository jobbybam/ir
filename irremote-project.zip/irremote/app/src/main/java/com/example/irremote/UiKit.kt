@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.irremote

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Black and grey palette. */
object Ui {
    val Bg = Color(0xFF000000)
    val Panel = Color(0xFF0F0F0F)
    val Raised = Color(0xFF161616)
    val Pressed = Color(0xFF2E2E2E)
    val Line = Color(0xFF2A2A2A)
    val Ink = Color(0xFFEDEDED)
    val Muted = Color(0xFF8C8C8C)
    val Dim = Color(0xFF454545)
}

val LocalSender = staticCompositionLocalOf<IrSender> { error("IrSender not provided") }

@Composable
fun IrTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Ui.Ink,
        onPrimary = Ui.Bg,
        secondary = Ui.Muted,
        onSecondary = Ui.Bg,
        background = Ui.Bg,
        onBackground = Ui.Ink,
        surface = Ui.Bg,
        onSurface = Ui.Ink,
        surfaceVariant = Ui.Raised,
        onSurfaceVariant = Ui.Muted,
        outline = Ui.Line,
        outlineVariant = Ui.Line,
        primaryContainer = Ui.Raised,
        onPrimaryContainer = Ui.Ink,
        surfaceContainerLowest = Ui.Bg,
        surfaceContainerLow = Ui.Panel,
        surfaceContainer = Ui.Raised,
        surfaceContainerHigh = Ui.Raised,
        surfaceContainerHighest = Ui.Raised
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

class Key(val name: String, val signal: IrSignal?)

@Composable
fun Ic(res: Int, tint: Color, size: Dp = 24.dp) {
    Icon(
        painter = painterResource(res),
        contentDescription = null,
        tint = tint,
        modifier = Modifier.size(size)
    )
}

/**
 * A pressable remote key. Tap sends once, holding past 400 ms repeats until release.
 * A null key or a key with an unsupported protocol is drawn dim and does nothing.
 */
@Composable
fun KeyBox(
    k: Key?,
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    container: Color = Ui.Raised,
    bordered: Boolean = true,
    content: @Composable BoxScope.(Color) -> Unit
) {
    val signal = k?.signal
    val sender = LocalSender.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var pressed by remember { mutableStateOf(false) }

    val tint = if (signal != null) Ui.Ink else Ui.Dim
    val fill = if (pressed && signal != null) Ui.Pressed else container

    var m = modifier.clip(shape).background(fill, shape)
    if (bordered) m = m.border(1.dp, Ui.Line, shape)
    if (signal != null) {
        m = m.pointerInput(signal) {
            var held = false
            detectTapGestures(
                onPress = {
                    held = false
                    pressed = true
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    val repeater = scope.launch(Dispatchers.Default) {
                        delay(400)
                        held = true
                        sender.hold(signal, 15_000)
                    }
                    tryAwaitRelease()
                    repeater.cancel()
                    pressed = false
                },
                onTap = {
                    if (!held) scope.launch(Dispatchers.Default) { sender.send(signal) }
                }
            )
        }
    }

    Box(m, contentAlignment = Alignment.Center) { content(tint) }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        border = BorderStroke(1.dp, Ui.Line),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Ui.Ink)
    ) { Text(text) }
}

@Composable
fun SolidButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Ui.Ink, contentColor = Ui.Bg)
    ) { Text(text) }
}

/** Icon-only bottom bar. */
@Composable
fun MinimalBar(selected: Int, onSelect: (Int) -> Unit) {
    val icons = listOf(R.drawable.ic_remote, R.drawable.ic_bookmark, R.drawable.ic_bluetooth)
    Column(Modifier.fillMaxWidth().background(Ui.Bg)) {
        HorizontalDivider(color = Ui.Line)
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().height(56.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            icons.forEachIndexed { i, res ->
                Box(
                    Modifier.weight(1f).fillMaxHeight().clickable { onSelect(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Ic(res, if (selected == i) Ui.Ink else Ui.Dim, 26.dp)
                }
            }
        }
    }
}
