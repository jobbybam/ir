@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.irremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)

        val sender = IrSender(this)
        val store = SavedStore(this)
        val dbResult = runCatching { IrDatabase.open(applicationContext) }

        setContent {
            IrTheme {
                Surface(Modifier.fillMaxSize(), color = Ui.Bg) {
                    val db = dbResult.getOrNull()
                    if (db == null) {
                        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                            Text(
                                "Database not found: ${dbResult.exceptionOrNull()?.message}",
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        App(db, sender, store)
                    }
                }
            }
        }
    }
}

@Composable
fun App(db: IrDatabase, sender: IrSender, store: SavedStore) {
    var tab by rememberSaveable { mutableStateOf(0) }
    var path by rememberSaveable { mutableStateOf(store.lastPath ?: "") }
    var savedId by rememberSaveable { mutableStateOf(store.lastId) }

    val openRemote: (String, String?) -> Unit = { p, id ->
        path = p
        savedId = id
        store.lastPath = p
        store.lastId = id
    }

    CompositionLocalProvider(LocalSender provides sender) {
        Scaffold(
            containerColor = Ui.Bg,
            bottomBar = { MinimalBar(tab) { tab = it } }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (!sender.available) {
                    Text(
                        "No IR blaster on this phone, sending is disabled.",
                        color = Ui.Muted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                    )
                }
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> RemoteTab(db, store, path, savedId, openRemote)
                        1 -> MyRemotesTab(store) { p, id ->
                            openRemote(p, id)
                            tab = 0
                        }
                        else -> BleTab()
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Remote tab

@Composable
fun RemoteTab(
    db: IrDatabase,
    store: SavedStore,
    path: String,
    savedId: String?,
    onOpen: (String, String?) -> Unit
) {
    var browsing by rememberSaveable { mutableStateOf(false) }
    var type by rememberSaveable { mutableStateOf<String?>(null) }
    var brand by rememberSaveable { mutableStateOf<String?>(null) }

    val current: Device? = remember(path) { if (path.isEmpty()) null else db.deviceByPath(path) }
    val showPicker = browsing || current == null

    fun open(p: String, id: String?) {
        onOpen(p, id)
        browsing = false
        type = null
        brand = null
    }

    BackHandler(enabled = showPicker && (brand != null || type != null || current != null)) {
        when {
            brand != null -> brand = null
            type != null -> type = null
            else -> browsing = false
        }
    }

    val t = type
    val b = brand

    if (!showPicker && current != null) {
        val name = store.items.firstOrNull { it.id == savedId }?.name ?: current.model
        RemoteScreen(
            db = db,
            store = store,
            device = current,
            savedId = savedId,
            name = name,
            onOpen = { p, id -> open(p, id) },
            onBrowse = {
                browsing = true
                type = null
                brand = null
            }
        )
    } else {
        when {
            t == null -> PickList(
                title = "Device type",
                options = remember { db.types() },
                searchable = false,
                onBack = if (current != null) ({ browsing = false }) else null,
                header = { SavedSection(store) { open(it.path, it.id) } },
                onPick = { type = it }
            )
            b == null -> PickList(
                title = "Brand",
                options = remember(t) { db.brands(t) },
                searchable = true,
                onBack = { type = null },
                onPick = { brand = it }
            )
            else -> ModelList(db, t, b, onBack = { brand = null }) { open(it.path, null) }
        }
    }
}

@Composable
fun SavedSection(store: SavedStore, onOpen: (SavedRemote) -> Unit) {
    if (store.items.isEmpty()) return
    Column(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
        SectionLabel("My remotes")
        store.items.toList().forEach { saved ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    saved.name,
                    color = Ui.Ink,
                    modifier = Modifier.weight(1f).clickable { onOpen(saved) }.padding(vertical = 14.dp)
                )
            }
            HorizontalDivider(color = Ui.Line)
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text.uppercase(), color = Ui.Muted, fontSize = 12.sp, letterSpacing = 2.sp)
}

@Composable
fun PickList(
    title: String,
    options: List<String>,
    searchable: Boolean,
    onBack: (() -> Unit)? = null,
    header: @Composable () -> Unit = {},
    onPick: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val shown = if (query.isBlank()) options else options.filter { it.contains(query, ignoreCase = true) }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(onClick = onBack) { Ic(R.drawable.ic_back, Ui.Ink, 22.dp) }
            }
            Text(title, color = Ui.Ink, fontSize = 20.sp, fontWeight = FontWeight.Light)
        }
        header()
        if (searchable) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search", color = Ui.Muted) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Ui.Muted,
                    unfocusedBorderColor = Ui.Line,
                    cursorColor = Ui.Ink
                ),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            )
        }
        LazyColumn {
            items(shown) { s ->
                Text(
                    s,
                    color = Ui.Ink,
                    modifier = Modifier.fillMaxWidth().clickable { onPick(s) }.padding(vertical = 16.dp)
                )
                HorizontalDivider(color = Ui.Line)
            }
        }
    }
}

@Composable
fun ModelList(
    db: IrDatabase,
    type: String,
    brand: String,
    onBack: () -> Unit,
    onUse: (Device) -> Unit
) {
    val models = remember(type, brand) { db.models(type, brand) }
    val sender = LocalSender.current
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Ic(R.drawable.ic_back, Ui.Ink, 22.dp) }
            Text(brand, color = Ui.Ink, fontSize = 20.sp, fontWeight = FontWeight.Light)
        }
        Text(
            "Tap the power icon on each model until your device reacts, then tap Use.",
            color = Ui.Muted,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        LazyColumn {
            items(models) { m ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(m.model, color = Ui.Ink, modifier = Modifier.weight(1f), maxLines = 2)
                    IconButton(onClick = {
                        scope.launch(Dispatchers.Default) {
                            val code = db.powerCode(m.id)
                            code?.let { c -> IrEncoder.encode(c)?.let { sender.send(it) } }
                        }
                    }) { Ic(R.drawable.ic_power, Ui.Ink, 22.dp) }
                    SolidButton("Use", onClick = { onUse(m) })
                }
                HorizontalDivider(color = Ui.Line)
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
