@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.irremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.lazy.grid.items as gridItems

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sender = IrSender(this)
        val dbResult = runCatching { IrDatabase.open(applicationContext) }
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    val db = dbResult.getOrNull()
                    if (db == null) {
                        CenterText("Database not found: ${dbResult.exceptionOrNull()?.message}")
                    } else {
                        App(db, sender)
                    }
                }
            }
        }
    }
}

@Composable
fun CenterText(text: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, textAlign = TextAlign.Center)
    }
}

@Composable
fun App(db: IrDatabase, sender: IrSender) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = listOf("⏻" to "OFF", "📺" to "Remote", "🔵" to "BLE")

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icon) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (!sender.available) {
                Text(
                    "This phone has no IR blaster, so sending is disabled.",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(12.dp)
                )
            }
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> OffScreen(db, sender)
                    1 -> RemoteTab(db, sender)
                    else -> CenterText("BLE editor coming next")
                }
            }
        }
    }
}

// ---------------------------------------------------------------- OFF button

@Composable
fun OffScreen(db: IrDatabase, sender: IrSender) {
    val codes = remember { db.powerCodes() }
    var quick by remember { mutableStateOf(true) }
    var running by remember { mutableStateOf(false) }
    var done by remember { mutableIntStateOf(0) }
    var job by remember { mutableStateOf<Job?>(null) }
    val scope = rememberCoroutineScope()

    val list = if (quick) codes.take(100) else codes
    val total = list.size.coerceAtLeast(1)

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { done / total.toFloat() },
                modifier = Modifier.fillMaxSize(),
                strokeWidth = 10.dp
            )
            Button(
                onClick = {
                    if (running) {
                        job?.cancel()
                    } else {
                        done = 0
                        running = true
                        job = scope.launch(Dispatchers.Default) {
                            try {
                                sender.sendAll(list) { d, _ -> done = d }
                            } finally {
                                running = false
                            }
                        }
                    }
                },
                modifier = Modifier.size(230.dp),
                shape = CircleShape
            ) {
                Text(if (running) "STOP" else "OFF", fontSize = 48.sp)
            }
        }

        Text(
            if (running || done > 0) "$done / ${list.size} codes" else "${list.size} codes ready",
            modifier = Modifier.padding(top = 16.dp)
        )

        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = quick,
                onClick = { if (!running) quick = true },
                label = { Text("Quick (top ${minOf(100, codes.size)})") }
            )
            FilterChip(
                selected = !quick,
                onClick = { if (!running) quick = false },
                label = { Text("All (${codes.size})") }
            )
        }

        Text(
            "Point the phone at the screen. Toggle-power TVs may turn back on if they receive their code twice.",
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 16.dp)
        )
    }
}

// ---------------------------------------------------------------- Remote tab

@Composable
fun RemoteTab(db: IrDatabase, sender: IrSender) {
    var type by rememberSaveable { mutableStateOf<String?>(null) }
    var brand by rememberSaveable { mutableStateOf<String?>(null) }
    var deviceId by rememberSaveable { mutableStateOf<Long?>(null) }
    var deviceName by rememberSaveable { mutableStateOf("") }

    BackHandler(enabled = type != null) {
        when {
            deviceId != null -> deviceId = null
            brand != null -> brand = null
            else -> type = null
        }
    }

    val t = type
    val b = brand
    val d = deviceId
    when {
        t == null -> PickList("Device type", remember { db.types() }, searchable = false) { type = it }
        b == null -> PickList("Brand", remember(t) { db.brands(t) }, searchable = true) { brand = it }
        d == null -> ModelList(db, sender, t, b) { id, name ->
            deviceId = id
            deviceName = name
        }
        else -> RemoteView(db, sender, d, deviceName)
    }
}

@Composable
fun PickList(title: String, items: List<String>, searchable: Boolean, onPick: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    val shown = if (query.isBlank()) items else items.filter { it.contains(query, ignoreCase = true) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge)
        if (searchable) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
        }
        LazyColumn {
            items(shown) { s ->
                TextButton(onClick = { onPick(s) }, modifier = Modifier.fillMaxWidth()) {
                    Text(s, Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                }
            }
        }
    }
}

@Composable
fun ModelList(
    db: IrDatabase,
    sender: IrSender,
    type: String,
    brand: String,
    onUse: (Long, String) -> Unit
) {
    val models = remember(type, brand) { db.models(type, brand) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(brand, style = MaterialTheme.typography.titleLarge)
        Text(
            "Tap Test power on each model until your device reacts, then tap Use.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        LazyColumn {
            items(models) { m ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(m.model, Modifier.weight(1f), maxLines = 2)
                    OutlinedButton(onClick = {
                        scope.launch(Dispatchers.Default) {
                            val power = db.buttons(m.id).firstOrNull { isPowerName(it.name) }
                            power?.let { btn -> IrEncoder.encode(btn.code)?.let { sender.send(it) } }
                        }
                    }) { Text("Test power") }
                    Button(
                        onClick = { onUse(m.id, m.model) },
                        modifier = Modifier.padding(start = 6.dp)
                    ) { Text("Use") }
                }
            }
        }
    }
}

private val BUTTON_ORDER = listOf(
    "power", "power_off", "off", "input", "source", "vol_up", "vol_dn", "mute",
    "ch_next", "ch_prev", "up", "down", "left", "right", "ok", "back", "menu", "home"
)

@Composable
fun RemoteView(db: IrDatabase, sender: IrSender, deviceId: Long, name: String) {
    val entries = remember(deviceId) {
        db.buttons(deviceId)
            .sortedBy { b ->
                val i = BUTTON_ORDER.indexOf(b.name.trim().lowercase().replace(' ', '_'))
                if (i >= 0) i else BUTTON_ORDER.size
            }
            .map { it to IrEncoder.encode(it.code) }
    }

    Column(Modifier.fillMaxSize()) {
        Text(name, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp))
        Text(
            "Tap to send, hold to repeat. Greyed buttons use a protocol this app can't send yet.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            gridItems(entries) { (btn, signal) ->
                RemoteButton(btn.name.replace('_', ' '), signal, sender)
            }
        }
    }
}

@Composable
fun RemoteButton(label: String, signal: IrSignal?, sender: IrSender) {
    val scope = rememberCoroutineScope()
    val base = Modifier.fillMaxWidth().height(64.dp).alpha(if (signal != null) 1f else 0.4f)
    val modifier = if (signal == null) {
        base
    } else {
        base.pointerInput(signal) {
            var held = false
            detectTapGestures(
                onPress = {
                    held = false
                    val repeater = scope.launch(Dispatchers.Default) {
                        delay(400)
                        held = true
                        sender.hold(signal, 15_000)
                    }
                    tryAwaitRelease()
                    repeater.cancel()
                },
                onTap = {
                    if (!held) scope.launch(Dispatchers.Default) { sender.send(signal) }
                }
            )
        }
    }

    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = if (signal != null) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(label, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}
