@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.irremote

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import java.util.UUID

// ------------------------------------------------------------------ permissions

fun blePermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 31) {
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

fun hasBlePermissions(context: Context): Boolean =
    blePermissions().all { context.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

// ------------------------------------------------------------------ helpers

private val SHORT_NAMES = mapOf(
    0x1800 to "Generic Access",
    0x1801 to "Generic Attribute",
    0x180A to "Device Information",
    0x180F to "Battery",
    0x2A00 to "Device Name",
    0x2A01 to "Appearance",
    0x2A19 to "Battery Level",
    0x2A24 to "Model Number",
    0x2A25 to "Serial Number",
    0x2A26 to "Firmware Revision",
    0x2A27 to "Hardware Revision",
    0x2A28 to "Software Revision",
    0x2A29 to "Manufacturer Name"
)

private const val NAME_UUID = 0x2A00

fun shortUuid(u: UUID): Int? {
    val s = u.toString()
    return if (s.startsWith("0000") && s.endsWith("-0000-1000-8000-00805f9b34fb")) {
        s.substring(4, 8).toInt(16)
    } else null
}

fun uuidLabel(u: UUID): String {
    val short = shortUuid(u) ?: return u.toString()
    return SHORT_NAMES[short] ?: "0x%04X".format(short)
}

fun errorText(status: Int): String = when (status) {
    2 -> "Read not permitted"
    3 -> "The device doesn't allow writing this value"
    5 -> "Needs pairing (insufficient authentication)"
    7 -> "Invalid offset"
    13 -> "Wrong value length for this field"
    15 -> "Needs pairing (insufficient encryption)"
    -1 -> "Android couldn't start the operation"
    -2 -> "Device disconnected"
    else -> "Error $status"
}

fun toHex(b: ByteArray): String = b.joinToString(" ") { "%02X".format(it) }

fun toText(b: ByteArray): String = String(b, Charsets.UTF_8).map { if (it.code < 32) '·' else it }.joinToString("")

fun toNumber(b: ByteArray): String {
    if (b.isEmpty() || b.size > 4) return "n/a"
    var v = 0L
    b.forEachIndexed { i, x -> v = v or ((x.toLong() and 0xFF) shl (8 * i)) }
    return v.toString()
}

/** Formats a value for display: mode 0 = hex, 1 = text, 2 = number. */
fun formatValue(b: ByteArray?, mode: Int): String = when {
    b == null -> ""
    mode == 0 -> toHex(b)
    mode == 1 -> toText(b)
    else -> toNumber(b)
}

/** Parses what the user typed; null if invalid. [lengthHint] is the current value's size for numbers. */
fun parseInput(text: String, mode: Int, lengthHint: Int): ByteArray? = when (mode) {
    0 -> {
        val clean = text.replace("0x", "").replace(" ", "").replace(":", "")
        if (clean.isEmpty() || clean.length % 2 != 0 || !clean.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) null
        else ByteArray(clean.length / 2) { clean.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }
    1 -> text.toByteArray(Charsets.UTF_8)
    else -> text.trim().toLongOrNull()?.let { n ->
        val size = if (lengthHint in 1..4) lengthHint else if (n > 0xFFFF) 4 else if (n > 0xFF) 2 else 1
        if (n < 0 || n >= (1L shl (8 * size))) null
        else ByteArray(size) { i -> ((n shr (8 * i)) and 0xFF).toByte() }
    }
}

// ------------------------------------------------------------------ nicknames (on this phone only)

class Nicknames(context: Context) {
    private val prefs = context.getSharedPreferences("ble_nicknames", Context.MODE_PRIVATE)
    val map = mutableStateMapOf<String, String>()

    init {
        prefs.all.forEach { (k, v) -> if (v is String) map[k] = v }
    }

    fun set(address: String, name: String) {
        if (name.isBlank()) {
            map.remove(address)
            prefs.edit().remove(address).apply()
        } else {
            map[address] = name
            prefs.edit().putString(address, name).apply()
        }
    }
}

// ------------------------------------------------------------------ GATT session

class CharRow(val service: UUID, val ch: BluetoothGattCharacteristic) {
    val canRead = ch.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0
    val canWrite = ch.properties and (
        BluetoothGattCharacteristic.PROPERTY_WRITE or
            BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE or
            BluetoothGattCharacteristic.PROPERTY_SIGNED_WRITE
        ) != 0
    val canNotify = ch.properties and (
        BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE
        ) != 0

    var value by mutableStateOf<ByteArray?>(null)
    var original: ByteArray? = null
    var message by mutableStateOf("")
    var lockedReason by mutableStateOf<String?>(null)

    val editable: Boolean get() = canWrite && lockedReason == null

    fun propsLabel(): String = buildString {
        if (canRead) append("read ")
        if (canWrite) append("write ")
        if (canNotify) append("notify ")
    }.trim()
}

private class Op(val start: () -> Boolean, val onDone: (status: Int, value: ByteArray?) -> Unit)

@SuppressLint("MissingPermission")
class GattSession(private val context: Context, private val device: BluetoothDevice) {

    val rows = mutableStateListOf<CharRow>()
    var status by mutableStateOf("Connecting...")
    var connected by mutableStateOf(false)

    private var gatt: BluetoothGatt? = null
    private val main = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<Op>()
    private var current: Op? = null

    // ---- operation queue: Android allows one GATT operation at a time ----

    private fun enqueue(op: Op) {
        queue.addLast(op)
        pump()
    }

    private fun pump() {
        if (current != null) return
        val op = queue.removeFirstOrNull() ?: return
        current = op
        val started = try { op.start() } catch (e: Exception) { false }
        if (!started) {
            current = null
            op.onDone(-1, null)
            pump()
        }
    }

    private fun complete(status: Int, value: ByteArray?) {
        val op = current ?: return
        current = null
        op.onDone(status, value)
        pump()
    }

    // ---- callbacks (always hop to the main thread) ----

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, newState: Int) {
            main.post {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    status = "Discovering services..."
                    try { g.discoverServices() } catch (e: Exception) { status = "Couldn't discover services" }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    connected = false
                    status = "Disconnected"
                    complete(-2, null)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            main.post { buildRows(g) }
        }

        // Android 13+
        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
            st: Int
        ) {
            main.post { complete(st, value) }
        }

        // Android 12 and older
        @Deprecated("Deprecated in Java")
        override fun onCharacteristicRead(
            g: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?,
            st: Int
        ) {
            if (Build.VERSION.SDK_INT >= 33) return
            @Suppress("DEPRECATION")
            val v = characteristic?.value?.copyOf()
            main.post { complete(st, v) }
        }

        override fun onCharacteristicWrite(
            g: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?,
            st: Int
        ) {
            main.post { complete(st, null) }
        }
    }

    // ---- public API ----

    fun connect() {
        gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    fun close() {
        queue.clear()
        current = null
        try {
            gatt?.disconnect()
            gatt?.close()
        } catch (e: Exception) {
            // ignore
        }
        gatt = null
    }

    fun pair(): Boolean = try { device.createBond() } catch (e: Exception) { false }

    private fun buildRows(g: BluetoothGatt) {
        rows.clear()
        for (s in g.services) for (c in s.characteristics) rows.add(CharRow(s.uuid, c))
        connected = true
        status = "${rows.size} characteristics"
        rows.filter { it.canRead }.forEach { readRow(it, expect = null) }
    }

    fun readRow(row: CharRow, expect: ByteArray?) {
        enqueue(Op({ gatt?.readCharacteristic(row.ch) == true }) { st, v ->
            if (st == BluetoothGatt.GATT_SUCCESS && v != null) {
                row.value = v
                if (row.original == null) row.original = v
                if (expect != null) {
                    row.message = if (v.contentEquals(expect)) "Saved and verified" else "The device kept a different value"
                }
            } else if (expect == null) {
                row.message = errorText(st)
            } else {
                row.message = "Written, but couldn't read back (${errorText(st)})"
            }
        })
    }

    fun write(row: CharRow, bytes: ByteArray) {
        if (!row.editable) return
        row.message = "Writing..."
        val props = row.ch.properties
        val noResponse = props and BluetoothGattCharacteristic.PROPERTY_WRITE == 0 &&
            props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
        val type = if (noResponse) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

        enqueue(Op({ doWrite(row.ch, bytes, type) }) { st, _ ->
            if (st == BluetoothGatt.GATT_SUCCESS) {
                if (row.canRead) {
                    readRow(row, expect = bytes)
                } else {
                    row.value = bytes
                    row.message = "Sent"
                }
            } else {
                row.message = errorText(st)
                if (st == 3 || st == 5 || st == 15) row.lockedReason = errorText(st)
            }
        })
    }

    @Suppress("DEPRECATION")
    private fun doWrite(c: BluetoothGattCharacteristic, bytes: ByteArray, type: Int): Boolean {
        val g = gatt ?: return false
        return if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(c, bytes, type) == BluetoothStatusCodes.SUCCESS
        } else {
            c.writeType = type
            c.value = bytes
            g.writeCharacteristic(c)
        }
    }

    fun nameRow(): CharRow? = rows.firstOrNull { shortUuid(it.ch.uuid) == NAME_UUID }
}

// ------------------------------------------------------------------ UI

class ScanItem(val address: String, val name: String?, val rssi: Int, val device: BluetoothDevice)

@Composable
fun BleTab() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasBlePermissions(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasBlePermissions(ctx)
    }
    val nicknames = remember { Nicknames(ctx) }
    var selected by remember { mutableStateOf<ScanItem?>(null) }

    BackHandler(enabled = selected != null) { selected = null }

    val sel = selected
    when {
        !granted -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("Bluetooth permission is needed to scan for and connect to devices.")
            Button(onClick = { launcher.launch(blePermissions()) }, modifier = Modifier.padding(top = 12.dp)) {
                Text("Allow")
            }
        }
        sel != null -> DeviceScreen(sel, nicknames) { selected = null }
        else -> ScanScreen(nicknames) { selected = it }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun ScanScreen(nicknames: Nicknames, onPick: (ScanItem) -> Unit) {
    val ctx = LocalContext.current
    val found = remember { mutableStateMapOf<String, ScanItem>() }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    val adapter = remember { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter }

    val callback = remember {
        object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val addr = result.device.address
                found[addr] = ScanItem(addr, result.scanRecord?.deviceName, result.rssi, result.device)
            }
        }
    }

    DisposableEffect(Unit) {
        if (adapter == null || !adapter.isEnabled) {
            error = "Turn Bluetooth on, then reopen this tab."
        } else {
            try {
                adapter.bluetoothLeScanner?.startScan(callback)
            } catch (e: Exception) {
                error = e.message ?: "Scan failed"
            }
        }
        onDispose {
            try { adapter?.bluetoothLeScanner?.stopScan(callback) } catch (e: Exception) { /* ignore */ }
        }
    }

    fun displayName(item: ScanItem) = nicknames.map[item.address] ?: item.name ?: "(unnamed)"

    val shown = found.values
        .filter {
            query.isBlank() ||
                displayName(it).contains(query, ignoreCase = true) ||
                it.address.contains(query, ignoreCase = true)
        }
        .sortedByDescending { it.rssi }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Nearby BLE devices", style = MaterialTheme.typography.titleLarge)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search name or address") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        Text("${shown.size} found, strongest first. Tap one to connect.", style = MaterialTheme.typography.bodySmall)
        LazyColumn {
            items(shown) { item ->
                Column(
                    Modifier.fillMaxWidth().clickable { onPick(item) }.padding(vertical = 10.dp)
                ) {
                    Text(displayName(item), style = MaterialTheme.typography.titleMedium)
                    Text("${item.address}   ${item.rssi} dBm", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun DeviceScreen(dev: ScanItem, nicknames: Nicknames, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val session = remember(dev.address) { GattSession(ctx, dev.device) }

    DisposableEffect(dev.address) {
        session.connect()
        onDispose { session.close() }
    }

    var newName by remember { mutableStateOf(nicknames.map[dev.address] ?: dev.name ?: "") }
    val nameRow = session.nameRow()

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                TextButton(onClick = onBack) {
                    Icon(painterResource(R.drawable.ic_back), contentDescription = "Back", modifier = Modifier.size(22.dp))
                }
                Text(
                    nicknames.map[dev.address] ?: dev.name ?: dev.address,
                    style = MaterialTheme.typography.titleLarge
                )
            }
            Text(session.status, style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                label = { Text("New name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                Button(
                    enabled = nameRow != null && nameRow.editable && newName.isNotBlank(),
                    onClick = { nameRow?.let { session.write(it, newName.toByteArray(Charsets.UTF_8)) } }
                ) { Text("Rename on device") }
                OutlinedButton(onClick = { nicknames.set(dev.address, newName) }) {
                    Text("Nickname on phone")
                }
            }
            Text(
                when {
                    nameRow == null -> "This device has no Device Name field. Use a phone nickname."
                    !nameRow.editable -> "The device's name is read-only. Use a phone nickname."
                    else -> nameRow.message
                },
                style = MaterialTheme.typography.bodySmall
            )
        }

        itemsIndexed(session.rows) { index, row ->
            if (index == 0 || session.rows[index - 1].service != row.service) {
                Text(
                    uuidLabel(row.service),
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                )
            }
            CharRowView(row, session)
        }
    }
}

@Composable
fun CharRowView(row: CharRow, session: GattSession) {
    var mode by remember { mutableStateOf(0) }
    var input by remember(row.value, mode) { mutableStateOf(formatValue(row.value, mode)) }
    val editable = row.editable
    val modeNames = listOf("Hex", "Text", "Num")

    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).alpha(if (editable) 1f else 0.55f)) {
        Text(uuidLabel(row.ch.uuid), style = MaterialTheme.typography.titleMedium)
        Text(
            row.propsLabel() + if (!editable) "   (read-only)" else "",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            enabled = editable,
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            modeNames.forEachIndexed { i, label ->
                TextButton(onClick = { mode = i }) { Text(if (mode == i) "[$label]" else label) }
            }
        }
        if (editable) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val bytes = parseInput(input, mode, row.value?.size ?: 0)
                    if (bytes == null) row.message = "That value isn't valid for this format"
                    else session.write(row, bytes)
                }) { Text("Save") }
                val orig = row.original
                if (orig != null && row.value?.contentEquals(orig) == false) {
                    OutlinedButton(onClick = { session.write(row, orig) }) { Text("Restore original") }
                }
            }
        }
        val reason = row.lockedReason
        if (reason != null && reason.contains("pairing")) {
            OutlinedButton(onClick = {
                row.message = if (session.pair()) "Pairing started, accept the prompt, then reconnect" else "Couldn't start pairing"
            }) { Text("Pair device") }
        }
        if (row.message.isNotEmpty()) Text(row.message, style = MaterialTheme.typography.bodySmall)
    }
}
