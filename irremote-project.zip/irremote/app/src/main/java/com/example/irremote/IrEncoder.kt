package com.example.irremote

import android.content.Context
import android.hardware.ConsumerIrManager
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive

/** Carrier frequency in Hz and an on/off pattern in microseconds (starts with "on"). */
class IrSignal(val frequency: Int, val pattern: IntArray)

/** One row of the `codes` table from irdb.sqlite / one entry of power_codes.json. */
class IrCode(
    val kind: String,            // "parsed" or "raw"
    val protocol: String? = null,
    val address: String? = null, // e.g. "04 00 00 00" (little-endian bytes, Flipper format)
    val command: String? = null,
    val frequency: Int? = null,
    val raw: IntArray? = null
)

/** Builds an alternating mark/space list, merging same-level neighbours. */
private class Pattern {
    private val list = ArrayList<Int>()

    fun mark(us: Int) = add(true, us)
    fun space(us: Int) = add(false, us)
    fun total() = list.sum()
    fun toArray() = list.toIntArray()

    private fun add(on: Boolean, us: Int) {
        if (list.isEmpty() && !on) return          // pattern must start with a mark
        val nextIsMark = list.size % 2 == 0
        if (on == nextIsMark) list.add(us) else list[list.lastIndex] += us
    }

    /** Pad with idle space so the frame lasts [periodUs] from [startTotal]. */
    fun padFrame(startTotal: Int, periodUs: Int) {
        val missing = periodUs - (total() - startTotal)
        if (missing > 0) space(missing)
    }
}

object IrEncoder {

    fun encode(code: IrCode): IrSignal? = when (code.kind) {
        "raw" -> {
            val data = code.raw
            if (data == null || data.size < 2) null
            else IrSignal(code.frequency ?: 38000, data)
        }
        "parsed" -> {
            val proto = code.protocol
            val addr = code.address?.let(::parseLe)
            val cmd = code.command?.let(::parseLe)
            if (proto == null || addr == null || cmd == null) null
            else encodeParsed(proto, addr, cmd)
        }
        else -> null
    }

    /** "04 00 00 00" -> 4 (first byte is least significant). */
    fun parseLe(hex: String): Long {
        var v = 0L
        hex.trim().split(Regex("\\s+")).forEachIndexed { i, b ->
            v = v or (b.toLong(16) shl (8 * i))
        }
        return v
    }

    fun encodeParsed(protocol: String, addr: Long, cmd: Long): IrSignal? = when (protocol) {
        "NEC" -> nec(38000, addr, 8, cmd, 8, inverted = true)
        "NECext" -> nec(38000, addr, 16, cmd, 16, inverted = false)
        "NEC42" -> nec(38000, addr, 13, cmd, 8, inverted = true)
        "NEC42ext" -> nec(38000, addr, 26, cmd, 16, inverted = false)
        "Samsung32" -> samsung32(addr, cmd)
        "RC5", "RC5X" -> rc5(addr, cmd)
        "RC6" -> rc6(addr, cmd)
        "SIRC" -> sirc(addr, 5, cmd)
        "SIRC15" -> sirc(addr, 8, cmd)
        "SIRC20" -> sirc(addr, 13, cmd)
        "RCA" -> rca(addr, cmd)
        else -> null // Kaseikyo, Pioneer, ... not implemented yet
    }

    // ---------- NEC family: 9 ms + 4.5 ms header, 560 us marks, 560/1690 us spaces, LSB first ----------

    private fun Pattern.necBits(value: Long, bits: Int) {
        for (i in 0 until bits) {
            mark(560)
            space(if ((value shr i) and 1L == 1L) 1690 else 560)
        }
    }

    private fun mask(bits: Int) = (1L shl bits) - 1

    private fun nec(freq: Int, addr: Long, addrBits: Int, cmd: Long, cmdBits: Int, inverted: Boolean): IrSignal {
        val p = Pattern()
        p.mark(9000); p.space(4500)
        val a = addr and mask(addrBits)
        val c = cmd and mask(cmdBits)
        p.necBits(a, addrBits)
        if (inverted) p.necBits(a.inv() and mask(addrBits), addrBits)
        p.necBits(c, cmdBits)
        if (inverted) p.necBits(c.inv() and mask(cmdBits), cmdBits)
        p.mark(560)
        p.padFrame(0, 108000)
        return IrSignal(freq, p.toArray())
    }

    // ---------- Samsung32: 4.5 ms + 4.5 ms header, address sent twice, command + inverted command ----------

    private fun samsung32(addr: Long, cmd: Long): IrSignal {
        val p = Pattern()
        p.mark(4500); p.space(4500)
        val a = addr and 0xFF
        val c = cmd and 0xFF
        p.necBits(a, 8)
        p.necBits(a, 8)
        p.necBits(c, 8)
        p.necBits(c.inv() and 0xFF, 8)
        p.mark(560)
        p.padFrame(0, 108000)
        return IrSignal(38000, p.toArray())
    }

    // ---------- RC5 / RC5X: 36 kHz Manchester, 889 us half-bits, MSB first ----------

    private fun Pattern.rc5Bit(bit: Int) {
        if (bit == 1) { space(889); mark(889) } else { mark(889); space(889) }
    }

    private fun rc5(addr: Long, cmd: Long): IrSignal {
        val p = Pattern()
        p.rc5Bit(1)                                   // start bit 1
        p.rc5Bit((((cmd shr 6) and 1L).toInt()) xor 1) // start bit 2 = inverted command bit 6 (RC5X)
        p.rc5Bit(0)                                   // toggle bit (not toggled between presses)
        for (i in 4 downTo 0) p.rc5Bit(((addr shr i) and 1L).toInt())
        for (i in 5 downTo 0) p.rc5Bit(((cmd shr i) and 1L).toInt())
        p.padFrame(0, 114000)
        return IrSignal(36000, p.toArray())
    }

    // ---------- RC6 mode 0: 36 kHz Manchester, 444 us half-bits, MSB first ----------

    private fun Pattern.rc6Bit(bit: Int, units: Int = 1) {
        val t = 444 * units
        if (bit == 1) { mark(t); space(t) } else { space(t); mark(t) }
    }

    private fun rc6(addr: Long, cmd: Long): IrSignal {
        val p = Pattern()
        p.mark(2664); p.space(888)                    // leader
        p.rc6Bit(1)                                   // start bit
        repeat(3) { p.rc6Bit(0) }                     // mode 0
        p.rc6Bit(0, units = 2)                        // trailer / toggle bit is double width
        for (i in 7 downTo 0) p.rc6Bit(((addr shr i) and 1L).toInt())
        for (i in 7 downTo 0) p.rc6Bit(((cmd shr i) and 1L).toInt())
        p.padFrame(0, 107000)
        return IrSignal(36000, p.toArray())
    }

    // ---------- RCA: 56 kHz, 4 ms + 4 ms header, 500 us marks, 1000/2000 us spaces, MSB first ----------

    private fun rca(addr: Long, cmd: Long): IrSignal {
        val a = addr and 0xF
        val c = cmd and 0xFF
        val word = (a shl 20) or (c shl 12) or ((a.inv() and 0xF) shl 8) or (c.inv() and 0xFF)
        val p = Pattern()
        p.mark(4000); p.space(4000)
        for (i in 23 downTo 0) {
            p.mark(500)
            p.space(if ((word shr i) and 1L == 1L) 2000 else 1000)
        }
        p.mark(500)
        p.padFrame(0, 64000)
        return IrSignal(56000, p.toArray())
    }

    // ---------- Sony SIRC: 40 kHz, 2400 us header, 1200/600 us marks, frame sent 3x every 45 ms ----------

    private fun sirc(addr: Long, addrBits: Int, cmd: Long): IrSignal {
        val p = Pattern()
        repeat(3) {
            val start = p.total()
            p.mark(2400); p.space(600)
            for (i in 0 until 7) {                    // 7 command bits, LSB first
                p.mark(if ((cmd shr i) and 1L == 1L) 1200 else 600); p.space(600)
            }
            for (i in 0 until addrBits) {             // address bits, LSB first
                p.mark(if ((addr shr i) and 1L == 1L) 1200 else 600); p.space(600)
            }
            p.padFrame(start, 45000)
        }
        return IrSignal(40000, p.toArray())
    }
}

/** Thin wrapper around ConsumerIrManager. Needs <uses-permission android:name="android.permission.TRANSMIT_IR"/>. */
class IrSender(context: Context) {
    private val ir = context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    val available: Boolean get() = ir?.hasIrEmitter() == true

    /** Moves [freq] into the nearest range this phone's emitter supports. */
    private fun nearestSupported(freq: Int): Int {
        val ranges = ir?.carrierFrequencies ?: return freq
        if (ranges.isEmpty() || ranges.any { freq in it.minFrequency..it.maxFrequency }) return freq
        return ranges.flatMap { listOf(it.minFrequency, it.maxFrequency) }
            .minByOrNull { kotlin.math.abs(it - freq) } ?: freq
    }

    /** Blocking; call from a background dispatcher. */
    fun send(signal: IrSignal) {
        ir?.transmit(nearestSupported(signal.frequency), signal.pattern)
    }

    /** Resends the frame back to back for [durationMs], e.g. volume hold or SMART Board power hold. */
    suspend fun hold(signal: IrSignal, durationMs: Long) {
        val end = System.currentTimeMillis() + durationMs
        while (System.currentTimeMillis() < end) {
            currentCoroutineContext().ensureActive()
            send(signal)
        }
    }

    /** Off-button loop: sends every code once with a small gap, reporting progress. */
    suspend fun sendAll(
        codes: List<IrCode>,
        gapMs: Long = 150,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ) {
        codes.forEachIndexed { i, code ->
            currentCoroutineContext().ensureActive()
            IrEncoder.encode(code)?.let { send(it) }
            onProgress(i + 1, codes.size)
            delay(gapMs)
        }
    }
}
