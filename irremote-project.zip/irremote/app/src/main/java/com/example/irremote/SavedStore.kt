package com.example.irremote

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** A remote in "My remotes": a user-chosen name pointing at a device in the database. */
class SavedRemote(val id: String, val name: String, val path: String)

/** Saved remotes, kept in SharedPreferences. The same device can be saved several times under different names. */
class SavedStore(context: Context) {
    private val prefs = context.getSharedPreferences("saved_remotes", Context.MODE_PRIVATE)
    val items = mutableStateListOf<SavedRemote>()

    init {
        var upgraded = false
        runCatching {
            val arr = JSONArray(prefs.getString("list", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                var id = o.optString("id", "")
                if (id.isEmpty()) {
                    id = UUID.randomUUID().toString()
                    upgraded = true
                }
                items.add(SavedRemote(id, o.getString("name"), o.getString("path")))
            }
        }
        if (upgraded) persist()
    }

    /** Device path of the remote that was open last. */
    var lastPath: String?
        get() = prefs.getString("last", null)
        set(value) {
            prefs.edit().putString("last", value).apply()
        }

    /** Id of the saved remote that was open last, if it was a saved one. */
    var lastId: String?
        get() = prefs.getString("last_id", null)
        set(value) {
            prefs.edit().putString("last_id", value).apply()
        }

    fun get(id: String): SavedRemote? = items.firstOrNull { it.id == id }

    fun add(name: String, path: String): SavedRemote {
        val remote = SavedRemote(UUID.randomUUID().toString(), name, path)
        items.add(remote)
        persist()
        return remote
    }

    fun remove(id: String) {
        items.removeAll { it.id == id }
        persist()
    }

    fun rename(id: String, newName: String) {
        val i = items.indexOfFirst { it.id == id }
        if (i < 0 || newName.isBlank()) return
        items[i] = SavedRemote(id, newName.trim(), items[i].path)
        persist()
    }

    private fun persist() {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("path", it.path))
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }
}
