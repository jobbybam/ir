@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.irremote

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun normName(s: String): String =
    s.lowercase().replace("+", "plus").replace("-", "minus").filter { it.isLetterOrDigit() }

/** Maps a device's buttons onto the fixed slots of the remote layout. */
class KeyMap(buttons: List<IrButton>) {
    val all: List<Key> = buttons.map { Key(it.name, IrEncoder.encode(it.code)) }
    private val byName = HashMap<String, Key>()

    init {
        for (k in all) {
            val n = normName(k.name)
            val existing = byName[n]
            if (existing == null || (existing.signal == null && k.signal != null)) byName[n] = k
        }
    }

    private fun find(vararg aliases: String): Key? = aliases.firstNotNullOfOrNull { byName[it] }

    val power = find("power", "poweroff", "off", "poweronoff", "standby", "powertoggle", "onoff")
    val input = find("input", "source", "tvinput", "inputsource", "av")
    val up = find("up", "navup", "cursorup", "arrowup", "dpadup", "navigationup")
    val down = find("down", "navdown", "cursordown", "arrowdown", "dpaddown", "navigationdown")
    val left = find("left", "navleft", "cursorleft", "arrowleft", "dpadleft", "navigationleft")
    val right = find("right", "navright", "cursorright", "arrowright", "dpadright", "navigationright")
    val ok = find("ok", "enter", "select", "center", "okenter")
    val back = find("back", "return", "exit")
    val home = find("home", "smarthub", "hub", "homepage")
    val menu = find("menu", "settings", "tools", "options")
    val volUp = find("volup", "volumeup", "volplus", "volumeplus", "vup")
    val volDown = find("voldn", "voldown", "volumedown", "volminus", "volumeminus", "vdown", "voldwn")
    val mute = find("mute", "muteunmute", "volmute")
    val chUp = find("chnext", "chup", "channelup", "chplus", "channelplus", "chnxt")
    val chDown = find("chprev", "chdown", "chdn", "channeldown", "chminus", "channelminus", "chprevious")
}

@Composable
fun RemoteScreen(
    db: IrDatabase,
    store: SavedStore,
    device: Device,
    savedId: String?,
    name: String,
    onOpen: (String, String?) -> Unit,
    onBrowse: () -> Unit
) {
    val map = remember(device.id) { KeyMap(db.buttons(device.id)) }
    var showAll by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        RemoteHeader(device, store, savedId, name, onOpen, onBrowse)
        Spacer(Modifier.height(8.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            KeyBox(map.power, Modifier.size(60.dp)) { t -> Ic(R.drawable.ic_power, t, 26.dp) }
            KeyBox(map.input, Modifier.size(60.dp)) { t -> Ic(R.drawable.ic_input, t, 24.dp) }
        }

        Spacer(Modifier.height(28.dp))
        DPad(map)
        Spacer(Modifier.height(28.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            KeyBox(map.back, Modifier.size(56.dp)) { t -> Ic(R.drawable.ic_back, t) }
            KeyBox(map.home, Modifier.size(56.dp)) { t -> Ic(R.drawable.ic_home, t) }
            KeyBox(map.menu, Modifier.size(56.dp)) { t -> Ic(R.drawable.ic_menu, t) }
        }

        Spacer(Modifier.height(28.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Rocker("VOL", map.volUp, map.volDown)
            KeyBox(map.mute, Modifier.size(60.dp)) { t -> Ic(R.drawable.ic_mute, t, 26.dp) }
            Rocker("CH", map.chUp, map.chDown)
        }

        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { showAll = true }) {
            Text("All buttons", color = Ui.Muted, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showAll) {
        ModalBottomSheet(onDismissRequest = { showAll = false }, containerColor = Ui.Panel) {
            AllKeys(map)
        }
    }
}

@Composable
fun RemoteHeader(
    device: Device,
    store: SavedStore,
    savedId: String?,
    name: String,
    onOpen: (String, String?) -> Unit,
    onBrowse: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    val saved = savedId != null && store.get(savedId) != null

    Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) {
            Row(
                Modifier.clickable { menuOpen = true }.padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    name,
                    color = Ui.Ink,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Light,
                    maxLines = 1,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Ic(R.drawable.ic_chevron_down, Ui.Muted, 20.dp)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                store.items.toList().forEach { s ->
                    DropdownMenuItem(
                        text = { Text(s.name) },
                        onClick = {
                            menuOpen = false
                            onOpen(s.path, s.id)
                        }
                    )
                }
                if (saved) {
                    DropdownMenuItem(
                        text = { Text("Rename") },
                        onClick = {
                            menuOpen = false
                            renaming = true
                        }
                    )
                }
                DropdownMenuItem(
                    text = { Text("Browse devices") },
                    onClick = {
                        menuOpen = false
                        onBrowse()
                    }
                )
            }
        }
        IconButton(onClick = {
            if (saved && savedId != null) {
                store.remove(savedId)
                onOpen(device.path, null)
            } else {
                val r = store.add(device.model, device.path)
                onOpen(device.path, r.id)
            }
        }) {
            Ic(if (saved) R.drawable.ic_bookmark_filled else R.drawable.ic_bookmark, Ui.Ink, 24.dp)
        }
        IconButton(onClick = onBrowse) { Ic(R.drawable.ic_plus, Ui.Ink, 24.dp) }
    }

    if (renaming && savedId != null) {
        RenameDialog(
            initial = name,
            onSave = {
                store.rename(savedId, it)
                renaming = false
            },
            onDismiss = { renaming = false }
        )
    }
}

@Composable
fun DPad(map: KeyMap) {
    Box(
        Modifier
            .size(248.dp)
            .clip(CircleShape)
            .background(Ui.Raised)
            .border(1.dp, Ui.Line, CircleShape)
    ) {
        val arrow = RoundedCornerShape(32.dp)
        KeyBox(
            map.up,
            Modifier.align(Alignment.TopCenter).padding(top = 8.dp).size(76.dp, 64.dp),
            shape = arrow, container = Color.Transparent, bordered = false
        ) { t -> Ic(R.drawable.ic_chevron_up, t, 28.dp) }
        KeyBox(
            map.down,
            Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp).size(76.dp, 64.dp),
            shape = arrow, container = Color.Transparent, bordered = false
        ) { t -> Ic(R.drawable.ic_chevron_down, t, 28.dp) }
        KeyBox(
            map.left,
            Modifier.align(Alignment.CenterStart).padding(start = 8.dp).size(64.dp, 76.dp),
            shape = arrow, container = Color.Transparent, bordered = false
        ) { t -> Ic(R.drawable.ic_chevron_left, t, 28.dp) }
        KeyBox(
            map.right,
            Modifier.align(Alignment.CenterEnd).padding(end = 8.dp).size(64.dp, 76.dp),
            shape = arrow, container = Color.Transparent, bordered = false
        ) { t -> Ic(R.drawable.ic_chevron_right, t, 28.dp) }
        KeyBox(
            map.ok,
            Modifier.align(Alignment.Center).size(92.dp),
            container = Ui.Bg
        ) { t -> Text("OK", color = t, fontSize = 18.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp) }
    }
}

@Composable
fun Rocker(label: String, up: Key?, down: Key?) {
    val shape = RoundedCornerShape(38.dp)
    Column(
        Modifier
            .width(76.dp)
            .height(176.dp)
            .clip(shape)
            .background(Ui.Raised)
            .border(1.dp, Ui.Line, shape),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        KeyBox(
            up,
            Modifier.fillMaxWidth().weight(1f),
            shape = RoundedCornerShape(topStart = 38.dp, topEnd = 38.dp),
            container = Color.Transparent, bordered = false
        ) { t -> Ic(R.drawable.ic_plus, t, 26.dp) }
        Text(label, color = Ui.Muted, fontSize = 11.sp, letterSpacing = 2.sp)
        KeyBox(
            down,
            Modifier.fillMaxWidth().weight(1f),
            shape = RoundedCornerShape(bottomStart = 38.dp, bottomEnd = 38.dp),
            container = Color.Transparent, bordered = false
        ) { t -> Ic(R.drawable.ic_minus, t, 26.dp) }
    }
}

@Composable
fun AllKeys(map: KeyMap) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.heightIn(max = 480.dp)
    ) {
        items(map.all) { k ->
            KeyBox(
                k,
                Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) { t ->
                Text(
                    k.name.replace('_', ' '),
                    color = t,
                    fontSize = 13.sp,
                    maxLines = 2,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
            }
        }
    }
}
