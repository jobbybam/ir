@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.irremote

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun RenameDialog(initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ui.Raised,
        title = { Text("Rename remote") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Ui.Muted,
                    unfocusedBorderColor = Ui.Line,
                    cursorColor = Ui.Ink
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onSave(text.trim()) }) {
                Text("Save", color = Ui.Ink)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Ui.Muted) }
        }
    )
}

/** "TVs/Samsung/Samsung_UE55.ir" -> "Samsung  ·  Samsung_UE55" */
private fun describe(path: String): String =
    path.removeSuffix(".ir").split('/').drop(1).joinToString("  ·  ")

@Composable
fun MyRemotesTab(store: SavedStore, onOpen: (String, String?) -> Unit) {
    var renaming by remember { mutableStateOf<SavedRemote?>(null) }
    var removing by remember { mutableStateOf<SavedRemote?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("My remotes", color = Ui.Ink, fontSize = 20.sp, fontWeight = FontWeight.Light)
        }

        if (store.items.isEmpty()) {
            Text(
                "Nothing saved yet. Open a remote and tap the bookmark icon to save it here.",
                color = Ui.Muted,
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        LazyColumn {
            items(store.items.toList()) { r ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(
                        Modifier.weight(1f).clickable { onOpen(r.path, r.id) }.padding(vertical = 14.dp)
                    ) {
                        Text(r.name, color = Ui.Ink, fontSize = 17.sp)
                        Text(describe(r.path), color = Ui.Muted, fontSize = 12.sp, maxLines = 1)
                    }
                    IconButton(onClick = { renaming = r }) { Ic(R.drawable.ic_edit, Ui.Muted, 20.dp) }
                    IconButton(onClick = { removing = r }) { Ic(R.drawable.ic_delete, Ui.Muted, 20.dp) }
                }
                HorizontalDivider(color = Ui.Line)
            }
        }
    }

    val toRename = renaming
    if (toRename != null) {
        RenameDialog(
            initial = toRename.name,
            onSave = {
                store.rename(toRename.id, it)
                renaming = null
            },
            onDismiss = { renaming = null }
        )
    }

    val toRemove = removing
    if (toRemove != null) {
        AlertDialog(
            onDismissRequest = { removing = null },
            containerColor = Ui.Raised,
            title = { Text("Remove remote?") },
            text = { Text("\"${toRemove.name}\" will be removed from My remotes.") },
            confirmButton = {
                TextButton(onClick = {
                    store.remove(toRemove.id)
                    removing = null
                }) { Text("Remove", color = Ui.Ink) }
            },
            dismissButton = {
                TextButton(onClick = { removing = null }) { Text("Cancel", color = Ui.Muted) }
            }
        )
    }
}
