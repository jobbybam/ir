package com.example.irremote

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import java.io.File

class Device(val id: Long, val model: String, val path: String)

class IrButton(val name: String, val code: IrCode)

private val POWER_NAMES = setOf(
    "power", "power_off", "poweroff", "off", "power_toggle",
    "standby", "on_off", "onoff", "power_on_off"
)

fun isPowerName(name: String) = name.trim().lowercase().replace(' ', '_') in POWER_NAMES

/** Read-only access to the bundled IR database (built by tools/ir_convert.py). */
class IrDatabase private constructor(private val db: SQLiteDatabase) {

    fun types(): List<String> =
        column("SELECT DISTINCT type FROM devices ORDER BY type COLLATE NOCASE")

    fun brands(type: String): List<String> =
        column("SELECT DISTINCT brand FROM devices WHERE type=? ORDER BY brand COLLATE NOCASE", type)

    fun models(type: String, brand: String): List<Device> {
        val out = ArrayList<Device>()
        db.rawQuery(
            "SELECT id, model, path FROM devices WHERE type=? AND brand=? ORDER BY model COLLATE NOCASE",
            arrayOf(type, brand)
        ).use { c ->
            while (c.moveToNext()) out.add(Device(c.getLong(0), c.getString(1), c.getString(2)))
        }
        return out
    }

    fun deviceByPath(path: String): Device? {
        db.rawQuery("SELECT id, model, path FROM devices WHERE path=? LIMIT 1", arrayOf(path)).use { c ->
            return if (c.moveToFirst()) Device(c.getLong(0), c.getString(1), c.getString(2)) else null
        }
    }

    /** First Power/Off code of a device, or null. */
    fun powerCode(deviceId: Long): IrCode? =
        buttons(deviceId).firstOrNull { isPowerName(it.name) }?.code

    fun buttons(deviceId: Long): List<IrButton> {
        val out = ArrayList<IrButton>()
        db.rawQuery(
            "SELECT b.name, c.kind, c.protocol, c.address, c.command, c.frequency, c.raw " +
                "FROM buttons b JOIN codes c ON c.id = b.code_id " +
                "WHERE b.device_id = ? ORDER BY b.rowid",
            arrayOf(deviceId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val code = IrCode(
                    kind = c.getString(1),
                    protocol = if (c.isNull(2)) null else c.getString(2),
                    address = if (c.isNull(3)) null else c.getString(3),
                    command = if (c.isNull(4)) null else c.getString(4),
                    frequency = if (c.isNull(5)) null else c.getInt(5),
                    raw = if (c.isNull(6)) null else jsonToInts(JSONArray(c.getString(6)))
                )
                out.add(IrButton(c.getString(0), code))
            }
        }
        return out
    }

    private fun column(sql: String, vararg args: String): List<String> {
        val out = ArrayList<String>()
        db.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        return out
    }

    private fun jsonToInts(a: JSONArray) = IntArray(a.length()) { a.getInt(it) }

    companion object {
        /** Copies the bundled database out of assets on first run (and after app updates), then opens it. */
        fun open(context: Context): IrDatabase {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            val stamp = info.lastUpdateTime.toString()
            val dbFile = File(context.filesDir, "irdb.sqlite")
            val stampFile = File(context.filesDir, "irdb.stamp")

            if (!dbFile.exists() || !stampFile.exists() || stampFile.readText() != stamp) {
                context.assets.open("irdb.sqlite").use { input ->
                    dbFile.outputStream().use { input.copyTo(it) }
                }
                stampFile.writeText(stamp)
            }
            val db = SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READONLY)
            return IrDatabase(db)
        }
    }
}
