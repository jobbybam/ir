#!/usr/bin/env python3
"""Convert a Flipper-IRDB checkout into an app-ready SQLite database.

Usage:
  python ir_convert.py /path/to/Flipper-IRDB -o irdb.sqlite --power-json power_codes.json

Folder layout expected: <DeviceType>/<Brand>/<Model>.ir  (e.g. TVs/Samsung/Samsung_UE55.ir)

Output tables:
  devices(id, type, brand, model, path)
  codes(id, kind, protocol, address, command, frequency, duty, raw)   -- deduplicated
  buttons(device_id, name, code_id)

power_codes.json: deduplicated Power/Off codes from the chosen device types,
sorted by how many devices share each code (most common first).
"""
import argparse
import json
import re
import sqlite3
import sys
from collections import defaultdict
from pathlib import Path

POWER_NAMES = {"power", "power_off", "poweroff", "off", "power_toggle",
               "standby", "on_off", "onoff", "power_on_off"}


def parse_ir(text):
    """Parse one .ir file into a list of button dicts (lowercased keys)."""
    buttons, cur = [], {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, val = line.split(":", 1)
        key, val = key.strip().lower(), val.strip()
        if key == "name":
            if cur.get("name"):
                buttons.append(cur)
            cur = {"name": val}
        else:
            cur[key] = val
    if cur.get("name"):
        buttons.append(cur)
    return buttons


def normalize(btn):
    """Return a hashable code tuple, or None if the button is unusable."""
    kind = btn.get("type", "").lower()
    try:
        if kind == "parsed":
            proto = btn["protocol"]
            addr = " ".join(btn["address"].upper().split())
            cmd = " ".join(btn["command"].upper().split())
            return ("parsed", proto, addr, cmd, None, None, None)
        if kind == "raw":
            freq = int(btn["frequency"])
            duty = float(btn.get("duty_cycle", "0.33"))
            data = [int(x) for x in re.split(r"\s+", btn["data"].strip())]
            if len(data) < 2:
                return None
            return ("raw", None, None, None, freq, duty, json.dumps(data))
    except (KeyError, ValueError):
        return None
    return None


def build(root, db_path):
    root = Path(root)
    if Path(db_path).exists():
        Path(db_path).unlink()
    db = sqlite3.connect(db_path)
    db.executescript("""
        CREATE TABLE devices(id INTEGER PRIMARY KEY, type TEXT, brand TEXT, model TEXT, path TEXT);
        CREATE TABLE codes(id INTEGER PRIMARY KEY, kind TEXT, protocol TEXT, address TEXT,
                           command TEXT, frequency INTEGER, duty REAL, raw TEXT,
                           UNIQUE(kind, protocol, address, command, frequency, duty, raw));
        CREATE TABLE buttons(device_id INTEGER, name TEXT, code_id INTEGER);
        CREATE INDEX idx_dev ON devices(type, brand);
        CREATE INDEX idx_btn ON buttons(device_id);
    """)
    code_ids, n_files, n_buttons = {}, 0, 0
    for path in sorted(root.rglob("*.ir")):
        parts = path.relative_to(root).parts
        if len(parts) < 2 or parts[0].startswith((".", "_")):
            continue
        dtype = parts[0]
        brand = parts[1] if len(parts) >= 3 else path.stem
        try:
            buttons = parse_ir(path.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            continue
        rows = []
        for b in buttons:
            code = normalize(b)
            if code is None:
                continue
            if code not in code_ids:
                cur = db.execute(
                    "INSERT INTO codes(kind,protocol,address,command,frequency,duty,raw) "
                    "VALUES(?,?,?,?,?,?,?)", code)
                code_ids[code] = cur.lastrowid
            rows.append((b["name"], code_ids[code]))
        if not rows:
            continue
        dev_id = db.execute(
            "INSERT INTO devices(type,brand,model,path) VALUES(?,?,?,?)",
            (dtype, brand, path.stem, "/".join(parts))).lastrowid
        db.executemany("INSERT INTO buttons VALUES(?,?,?)",
                       [(dev_id, n, c) for n, c in rows])
        n_files += 1
        n_buttons += len(rows)
    db.commit()
    print(f"{n_files} devices, {n_buttons} buttons, {len(code_ids)} unique codes -> {db_path}")
    return db


def export_power(db, out_path, types):
    marks = ",".join("?" * len(types))
    q = f"""
        SELECT c.id, c.kind, c.protocol, c.address, c.command, c.frequency, c.duty, c.raw,
               d.id, d.brand, b.name
        FROM buttons b JOIN codes c ON c.id=b.code_id JOIN devices d ON d.id=b.device_id
        WHERE d.type IN ({marks})
    """
    codes = {}
    devices = defaultdict(set)
    brands = defaultdict(lambda: defaultdict(int))
    for cid, kind, proto, addr, cmd, freq, duty, raw, dev, brand, name in db.execute(q, types):
        if name.strip().lower().replace(" ", "_") not in POWER_NAMES:
            continue
        codes[cid] = dict(kind=kind, protocol=proto, address=addr, command=cmd,
                          frequency=freq, duty=duty,
                          raw=json.loads(raw) if raw else None)
        devices[cid].add(dev)
        brands[cid][brand] += 1
    out = []
    for cid, c in codes.items():
        top = sorted(brands[cid], key=lambda b: -brands[cid][b])[:3]
        out.append({"id": cid, **c, "uses": len(devices[cid]), "brands": top})
    out.sort(key=lambda c: -c["uses"])
    Path(out_path).write_text(json.dumps({"version": 1, "codes": out}, separators=(",", ":")))
    print(f"{len(out)} unique power codes -> {out_path}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("root", help="path to the Flipper-IRDB folder")
    ap.add_argument("-o", "--out", default="irdb.sqlite")
    ap.add_argument("--power-json", default="power_codes.json")
    ap.add_argument("--power-types", nargs="+", default=["TVs"],
                    help="device-type folders to use for the off button (default: TVs)")
    args = ap.parse_args()
    if not Path(args.root).is_dir():
        sys.exit(f"not a folder: {args.root}")
    db = build(args.root, args.out)
    export_power(db, args.power_json, args.power_types)
    db.close()


if __name__ == "__main__":
    main()
