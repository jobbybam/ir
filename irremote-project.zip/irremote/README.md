IR Remote (Kotlin + Jetpack Compose)

- tools/ir_convert.py   builds assets/irdb.sqlite + assets/power_codes.json from Flipper-IRDB
- IrEncoder.kt          protocol encoders + ConsumerIrManager sender
- IrDatabase.kt         loads the bundled database
- MainActivity.kt       OFF button, remote picker, remote screen, BLE tab placeholder
The GitHub Actions workflow (build.yml) runs the converter and builds the APK.
